# EarTraining
EarTraining è un'applicazione web su cui studiare musica e allenare il proprio orecchio musicale.
Il lato teorico è ancora in fase di sviluppo.

Per testare in locale, modificare correttamente, dove richiesto, i file "bridge2/connection.php" e "bridge2/install.php".
Per installare e popolare l'applicazione, andare al seguente uri: http://il_tuo_host/bridge2/install.php

## Documentazione
Consultare il file "EarTraining.docx"

## Riferimenti
L'applicazione è attualmente funzionante al seguente link: http://musicskills.altervista.org/
